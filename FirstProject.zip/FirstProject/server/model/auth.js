const db = require("../database/database");
class Authentication {
  constructor(name,Mname,Fname,Phone, Email, password,conform,DOB) {
    this.name = name;
    this.Mname = Mname;
    this.Fname = Fname;
    this.Phone = Phone;
    this.Email = Email;
    this.password = password;
    this.conform = conform;
    this.DOB = DOB;



  }

  save(req, res) {
    console.log("entered Data", this);
    db.execute("select email from signup where email = ?", [this.Email])
      .then((row) => {
        if (row[0].length != 0) {
          console.log("signup already exists");
          throw "signup already exixts";
        }
        if (this.conform != this.password) {
          throw "Password mismatch kindly review password";
        }
        db.execute("insert into signup (name,Mname,Fname,Phone,Email,password,DOB) values(?,?,?,?,?,?,?)", [
          this.name,
          this.Mname,
          this.Fname ,
          this.Phone,
          this.Email ,
          this.password ,
          this.DOB
        ]);
        console.log("signup created");
        res.send("success");
        return 0;
      })
      .catch((err) => {
        res.send(`failed: ${err}`);
        console.log("some error", err);
      })
      .catch((err) => {
        res.send("Datbase Error");
        console.log("Database", err);
      });
  }

  static login(req, res, next, body) {
    console.log("Entered Body:", body);
    db.execute(
      "select email,password from signup where email = ? and password=?",
      [body.email, body.password]
    )
      .then((row) => {
        if (row[0].length == 0) {
          console.log("Email or Password Incorrect");
          throw "Email or Password Incorrect";
        }
        // if (row.password != body.password) {
        //   throw "Password mismatch kindly review password";
        // }
        console.log("Login success");
        res.send("success");

        return 0;
      })
      .catch((err) => {
        res.send(`failed: ${err}`);
        console.log("some error", err);
      })
      .catch((err) => {
        res.send("Datbase Error");
        console.log("Database", err);
      });
  }
}

module.exports = Authentication;
