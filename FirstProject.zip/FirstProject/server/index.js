
const express = require("express");
const body_parser = require("body-parser");
const path = require("path");
const server = express();
const db = require("./database/database");
const Authentication = require("./model/auth");
const cors = require("cors");


const app = server;
const PORT = 4000;



app.use(cors());
app.use(express.static(path.join(__dirname, "public")));
app.use(body_parser.json({ extended: true }));
app.use(body_parser.json());


app.use("/signup", (req, res, next) => {
  console.log(req.body);
  const signup = new Authentication(
    req.body[0].name,
    req.body[0].Mname,
    req.body[0].Fname,
    req.body[0].Phone,
    req.body[0].Email,
    req.body[0].password,
    req.body[0].conform,
    req.body[0].DOB,
  );
  signup.save(req, res);

  // db.execute("select * from users")
  //   .then((row) => {
  //     console.log("Database", row);
  //   })
  //   .catch((err) => {
  //     console.log("Database", err);
  //   });
  
});

app.use("/login", (req, res, next) => {
  console.log(req.body);

  Authentication.login(req, res, next, {
    email: req.body[0].email,
    password: req.body[0].password,
  });

  db.execute("select * from signup")
    .then((row) => {
      console.log("Database", row);
    })
    .catch((err) => {
      console.log("Database", err);
    });
});
//server activation
app.use("/", (req, res, next) => {
  res.send("Reques Success");
});
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}...`);
});
