const index = (req, res, next) => {};

module.exports = { index };
