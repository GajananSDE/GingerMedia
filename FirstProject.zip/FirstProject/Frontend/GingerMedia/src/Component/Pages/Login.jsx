import { Link } from 'react-router-dom'
import { useState ,useEffect} from 'react'
import axios from "axios";
import './Login.css'
function Login() {
  const [formData, setFormData] = useState([]);
  const [message, setMessage] = useState(null);


  useEffect(() => {
    if (formData.length != 0) {
      axios
        .post("http://localhost:4000/login", { ...formData })
        .then((res) => {
          console.log(res);
          if(res.data === "success") {
            alert(res.data)
            }else{
              alert("Login Failed!")
            }
          setMessage(res.data);
          // navigate("/");
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [formData]);

  useEffect(() => {
    console.log(message);
  }, [message]);
  const handlelogin = (e) => {
    e.preventDefault();
    setFormData([
      { email: e.target.email.value, password: e.target.password.value },
    ]);
    console.log(e.target.password.value, e.target.email.value, formData);
  };
  return (
    <div className='main-container'>
       <div className="form-handle">
         <form action="" onSubmit={handlelogin} method='POST'>
           <div className="mb-3">
           <label htmlFor='email'>Email</label>
              <input type="email" placeholder='Enter Mail' className='form-control' name='email'/>
           </div>
           <div className="mb3">
           <label>Password</label>
              <input type="password" placeholder='Password' className='form-control' name='password' />
             
           </div>
           <button className="btn" type='submit'>Login</button>
           <p>You are agree to our term and policies</p>
          <Link to='/signup'> <button className="btn2">Create Account</button></Link>
         
         </form>
       
       </div>
           
             
         </div>
       
       )
}

export default Login
