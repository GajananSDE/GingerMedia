import './Signup.css'
import { Link } from 'react-router-dom'
import { useState ,useEffect} from 'react'
import { useNavigate } from "react-router-dom";
import axios from 'axios'
function Signup() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState([]);
  const [message, setMessage] = useState(null);
  useEffect(() => {
    if (formData.length != 0) {
      axios
        .post("http://localhost:4000/signup", { ...formData })
        .then((res) => {
          console.log(res);
          if(res.data === "success") {
          alert(res.data)
          }
          setMessage(res.data);
           navigate("/");
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [formData]);
  useEffect(() => {
    console.log(message);
  }, [message]);
  const handleLogin = (e) => {
    e.preventDefault();
    setFormData(() => {
      return [
        {
          name: e.target.name.value,
          Mname:e.target.Mname.value,
          Fname:e.target.Fname.value,
          Phone:e.target.Phone.value,
          Email: e.target.Email.value,
          password: e.target.password.value,
          conform: e.target.conform.value,
          DOB:e.target.DOB.value,
        },
      ];
    });

    console.log(e.target.password.value, e.target.Email.value, formData);
  };

  return (
    <div className='signup-page'>
      <div className="form-handling">
      <form onSubmit={handleLogin} method='POST'>
      <table>
      <tr>
      <td><label>Name</label> </td>
      <td><input type="text" name='name' /></td>
         </tr>
      <tr>
      <td><label htmlFor="">MotherName</label> </td>
      <td><input type="text" name='Mname' /></td>
       </tr>
      <tr>
      <td><label htmlFor="">FatherName</label> </td>
      <td><input type="text" name='Fname' /></td>
       </tr>

      <tr>
      <td><label htmlFor="">DOB</label> </td>
      <td><input type="date" name='DOB' /></td>
       </tr>
      <tr>
      <td><label htmlFor="">PhoneNo.</label> </td>
      <td><input type="tel" name='Phone' /></td>
          </tr>
      <tr>
      <td><label htmlFor="">EmailId</label> </td>
      <td><input type="Email" name='Email' /></td>
          </tr>
      <tr>
         <td><label htmlFor=""  >Password</label></td>
         <td><input type="text" name='password' /></td>
         </tr>
         <tr>
         <td><label htmlFor="">Confirm Password</label></td>
         <td><input type="text" name='conform' /></td>
         </tr>
         <div className="button-style">
         <button type='submit'>Submit</button>
         <button type='reset'>Reset</button>
         <Link to='/'> <button >Home</button></Link> 
         </div>
         </table>
         </form>
     
      </div>
    
    </div>
  )
}

export default Signup
